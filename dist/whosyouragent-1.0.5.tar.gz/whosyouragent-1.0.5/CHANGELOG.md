# Changelog

## 1.0.4 (2023-02-13)

#### Fixes

* wrap update_all() in try/except
#### Others

* add browserVersions.json to .gitignore