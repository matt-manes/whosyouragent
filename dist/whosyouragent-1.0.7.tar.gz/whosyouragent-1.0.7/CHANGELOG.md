# Changelog

## 1.0.6 (2023-02-13)

#### Fixes

* fix chrome version updater
* fix update failure handling

## v1.0.5 (2023-02-13)

#### Others

* build v1.0.5
* update changelog


## v1.0.4 (2023-02-13)

#### Fixes

* wrap update_all() in try/except
#### Others

* build v1.0.4
* update changelog
* add browserVersions.json to .gitignore