# Changelog

## 1.0.8 (2023-02-13)

#### Fixes

* fix creating browserVersions.json with {} instead of "{}" lol


## v1.0.7 (2023-02-13)

#### Fixes

* fix error occuring when browserVersions.json doesn't exist
* remove unused import
#### Others

* build v1.0.7
* update changelog
* update changelog


## v1.0.6 (2023-02-13)

#### Others

* build v1.0.6
* update changelog


## v1.0.5 (2023-02-13)

#### Others

* build v1.0.5
* update changelog


## v1.0.4 (2023-02-13)

#### Fixes

* wrap update_all() in try/except
#### Others

* build v1.0.4
* update changelog
* add browserVersions.json to .gitignore